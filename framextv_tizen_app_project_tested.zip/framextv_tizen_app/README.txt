FrameX TV — Samsung Tizen web app starter

This is a simple launcher project, not a streaming engine. It opens:
https://framextv.xyz/movie/1378537

Compatibility note:
- TV web apps use Tizen's web runtime. The site/player may or may not work on your exact TV firmware.
- This source project is not signed and is not an installable .wgt yet.
- To build/install, use Samsung Tizen Studio with the TV extension, create a Samsung certificate profile, import this project, then Build and install to the TV with Developer Mode enabled and the TV paired over the local network.
- No DRM, account, payment, or access controls are bypassed by this launcher.
